/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package viikko6;

/**
 *
 * @author s717467
 */
public class PrintDiamond {
	
	
    public void print(){
    System.out.println("   *  ");
    System.out.println("  *** ");
    System.out.println(" ***** ");
    System.out.println("*******");
    System.out.println(" ***** ");
    System.out.println("  *** ");
    System.out.println("   * ");
    }
            
            
    
    
}
